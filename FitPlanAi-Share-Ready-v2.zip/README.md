﻿# FitPlan AI Auth (Email OTP + Google Login)

## What this project does
- Modern auth UI with two tabs: `Sign In` and `Register`
- Login via:
  - Email + password
  - Google OAuth (optional, if configured)
- New user registration via OTP email verification
- Registration form captures profile fields (name, age, gender, goal, height, weight, activity level)

## Project structure
- `server.js` -> Node/Express backend
- `public/` -> frontend (`index.html`, `styles.css`, `app.js`)
- `.env.example` -> environment template (safe to share)
- `.env` -> real secrets (never share)

## Requirements
- Node.js 18+ (Node 20+ recommended)
- npm
- SMTP sender account (Gmail App Password or other SMTP provider)

## How to run from a shared ZIP (Windows)
1. Extract ZIP to a folder, for example `C:\FitPlanAi`
2. Open PowerShell in extracted folder
3. Install dependencies:
```powershell
npm install
```
4. Create your environment file:
```powershell
Copy-Item .env.example .env
```
5. Edit `.env` and fill all required values
6. Start server:
```powershell
node server.js
```
7. Open browser:
```text
http://localhost:3000
```

## .env configuration
Use this as a guide (replace placeholders):

```env
PORT=3000
OTP_SECRET=replace-with-a-random-secret
OTP_LENGTH=6
OTP_TTL_MINUTES=5
MAX_VERIFY_ATTEMPTS=5
MIN_SECONDS_BETWEEN_SENDS=45
SESSION_SECRET=replace-with-a-long-random-session-secret

SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-16-char-google-app-password
SMTP_FROM=FitPlan AI <your-email@gmail.com>
SMTP_SECURE=false

GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_CALLBACK_URL=http://localhost:3000/auth/google/callback
```

## Gmail setup (App Password for SMTP)
Use these steps if your sender is Gmail.

1. Sign in to the Gmail account you want as sender.
2. Go to Google Account Security: `https://myaccount.google.com/security`
3. Enable **2-Step Verification** (required).
4. In Security, open **App passwords**.
5. Create a new app password (Mail).
6. Copy the generated 16-character password.
7. Put it in `.env` as `SMTP_PASS`.

Important:
- Do **not** use your normal Gmail account password in `SMTP_PASS`.
- `SMTP_USER` must match the same Gmail account that generated the app password.
- Remove spaces if Google shows app password grouped like `xxxx xxxx xxxx xxxx`.

## Optional: Google login setup
If you want `Continue with Google` to work:

1. Create OAuth credentials in Google Cloud Console.
2. Add authorized redirect URI:
   - `http://localhost:3000/auth/google/callback`
3. Put values in `.env`:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`
   - `GOOGLE_CALLBACK_URL`

If not configured, email/password + OTP still works.

## API routes
- `POST /api/login`
- `POST /api/register/send-otp`
- `POST /api/register/verify-otp`
- `GET /auth/google`
- `GET /auth/google/callback`

## Security and sharing checklist
Before sharing code with others:

1. Never share `.env`.
2. Share `.env.example` only.
3. Revoke exposed app passwords immediately if leaked.
4. Do not include `node_modules` in ZIP.

## Current limitation
- User and OTP data are in-memory only.
- Restarting the server clears users and OTP state.
- For production, move to a database (MongoDB/Postgres).

## Troubleshooting
### 1) `Email service authentication failed. Please contact support.`
- Check `.env` sender values.
- Ensure `SMTP_USER` and `SMTP_PASS` are correct.
- For Gmail, confirm App Password + 2FA.

### 2) OTP not received
- Check spam folder.
- Verify `SMTP_FROM` format.
- Verify server logs for SMTP errors.

### 3) `User not found. Register first.`
- Register and verify OTP first.
- Remember users are lost after server restart (in-memory).
